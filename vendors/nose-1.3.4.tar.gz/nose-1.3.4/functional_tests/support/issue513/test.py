def test():
    raise '\xf1'.encode('ASCII')
    yield
