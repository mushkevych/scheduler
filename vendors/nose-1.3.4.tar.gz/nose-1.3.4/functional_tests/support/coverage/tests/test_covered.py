import blah

def test_blah():
    blah.dostuff()
