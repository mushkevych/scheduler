===========
 nosetests
===========

------------------------
nicer testing for python
------------------------

SYNOPSIS
========

  nosetests [options] [names]

DESCRIPTION
===========

.. autohelp ::
