.. automodule :: nose.commands
   :members: