.. automodule :: nose.plugins.plugintest

PluginTester methods
--------------------

.. autoclass :: nose.plugins.plugintest.PluginTester
   :members: