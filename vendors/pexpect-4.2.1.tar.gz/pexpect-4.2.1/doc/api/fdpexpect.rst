fdpexpect - use pexpect with a file descriptor
==============================================

.. automodule:: pexpect.fdpexpect

fdspawn class
-------------

.. autoclass:: fdspawn
   :show-inheritance:

   .. automethod:: __init__
   .. automethod:: isalive
   .. automethod:: close

   .. method:: expect
               expect_exact
               expect_list

      As :class:`pexpect.spawn`.
