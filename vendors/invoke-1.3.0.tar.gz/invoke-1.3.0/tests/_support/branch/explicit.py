from invoke import task


@task
def lyrics(c):
    print("Don't swear!")
