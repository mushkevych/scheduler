from mock import Mock


CustomExecutor = Mock()
