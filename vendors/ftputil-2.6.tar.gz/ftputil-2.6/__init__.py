# Copyright (C) 2003, Stefan Schwarzer <sschwarzer@sschwarzer.net>
# See the file LICENSE for licensing terms.

# Import everything into this namespace to comply with the old interface
#  when ftputil was a single module. Fortunately, this only imports
#  `FTPHost` at the moment. :-)
from ftputil import *

