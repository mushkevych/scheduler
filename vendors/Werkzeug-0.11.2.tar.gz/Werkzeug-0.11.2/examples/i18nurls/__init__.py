from i18nurls.application import Application as make_app
