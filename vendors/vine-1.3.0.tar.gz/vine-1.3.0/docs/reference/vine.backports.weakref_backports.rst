=====================================================
vine.backports.weakref_backports
=====================================================

.. contents::
    :local:
.. currentmodule:: vine.backports.weakref_backports

.. automodule:: vine.backports.weakref_backports
    :members:
    :undoc-members:
