.. include:: ../README.rst

Contents
========

.. toctree::
    :maxdepth: 2

    api

.. toctree::
    :maxdepth: 1

    license
    testing
    versions
