class NotATask(Exception):
    pass

def some_task():
    pass
