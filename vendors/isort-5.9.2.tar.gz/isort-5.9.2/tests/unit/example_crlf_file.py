import b
import a


def func():
    x = 1
    y = 2
    z = 3
    c = 4
    return x + y + z + c
