:orphan:

:mod:`ismaster` -- A wrapper for ismaster command responses.
============================================================

.. automodule:: pymongo.ismaster

   .. autoclass:: pymongo.ismaster.IsMaster(doc)

      .. autoattribute:: document
