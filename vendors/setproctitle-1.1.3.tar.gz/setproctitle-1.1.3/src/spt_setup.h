/*-------------------------------------------------------------------------
 *
 * spt_setup.h
 *    Initalization code for the spt_status.c module functions.
 *
 * Copyright (c) 2009-2011 Daniele Varrazzo <daniele.varrazzo@gmail.com>
 *
 *-------------------------------------------------------------------------
 */

#ifndef SPT_SETUP_H
#define SPT_SETUP_H

void spt_setup(void);

#endif
