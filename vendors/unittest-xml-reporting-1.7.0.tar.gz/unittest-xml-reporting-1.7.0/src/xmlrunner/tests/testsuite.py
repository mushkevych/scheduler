#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Executable module to test unittest-xml-reporting.
"""

import unittest
import xmlrunner

class XMLTestRunnerTestCase(unittest.TestCase):
    """XMLTestRunner test case.
    """
    pass

if __name__ == '__main__':
    unittest.main()
