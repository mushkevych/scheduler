import os
print("Line One")
os.chdir("subdir")
print("Line Two")
