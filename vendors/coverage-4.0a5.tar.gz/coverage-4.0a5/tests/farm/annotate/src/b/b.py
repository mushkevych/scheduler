def b(x):
    msg = "x is %s" % x
    print(msg)
