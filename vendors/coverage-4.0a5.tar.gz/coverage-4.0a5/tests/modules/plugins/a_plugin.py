"""A plugin for tests to reference."""

from coverage import CoveragePlugin

class Plugin(CoveragePlugin):
    pass
