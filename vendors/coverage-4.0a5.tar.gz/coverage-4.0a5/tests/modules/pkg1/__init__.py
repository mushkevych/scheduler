# This __init__.py has a module-level docstring, which is counted as a
# statement.
"""A simple package for testing with."""
