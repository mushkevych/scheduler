1.4
===

#9: Updated namespace package to use pkgutil for declaring the
namespace.

1.3
===

Tagged commits are automatically released following passing
tests.

1.2
===

Issue #5: Added a minimal test suite.

1.1
===

Moved hosting to Github.
Library uses setuptools_scm for version tagging.
Added license declaration.
