# merged into mock.py in Mock 0.7
