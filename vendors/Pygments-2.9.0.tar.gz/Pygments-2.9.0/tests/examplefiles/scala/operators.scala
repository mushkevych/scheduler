1 :: 2 :: Nil
a ++ b
a :+ b
a +: b
a :++ b
a ++: b
a + b