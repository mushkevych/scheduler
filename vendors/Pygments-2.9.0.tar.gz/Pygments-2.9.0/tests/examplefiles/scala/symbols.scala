// Symbols:
'* //test
'*
'symbol_*
'symbol1 //'
'ξφδ
'φδφ0
'δφξφξ_+-
'***

// Not (just) symbols:
'symbol*
'**_x //'
'x'