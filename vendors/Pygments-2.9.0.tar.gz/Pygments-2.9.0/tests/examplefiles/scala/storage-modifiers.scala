private object a {}
private[com] object b {}
private[com.example] object c {}
protected object d {}
protected[com] object e {}
protected[com.example] object f {}
synchronized {}
abstract class g {}
final val h = ???
lazy val i = ???
sealed trait j
implicit val k = ???
enum m {}
inline val n = ???
opaque type o = Unit
@volatile @transient @native
override def p = ???