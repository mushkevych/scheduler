Type[A with "user provided string" with B]
def help(id: UserName | Password) = ???
val either: Password | UserName = ???
val both: Object & Product = ???
<% =:= <:< <%< >: <:
[X, Y] =>> Map[Y, X]