/* comment */
/** doc comment */

namespace cpp shared // inline comment

struct Foo1 {
    1: i32 key
    2: string value
}

service Foo2 {
  Foo1 bar(1: i32 key)
}

