def "long function name"(i) { return i }
assert 'long function name'(1) == 1
