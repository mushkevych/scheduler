=====================================================================
 vine - Python Promises
=====================================================================

|build-status| |coverage| |bitdeli|

.. include:: ../includes/introduction.txt

.. |build-status| image:: https://secure.travis-ci.org/celery/vine.png?branch=master
    :alt: Build status
    :target: https://travis-ci.org/celery/vine

.. |coverage| image:: https://codecov.io/github/celery/vine/coverage.svg?branch=master
    :target: https://codecov.io/github/celery/vine?branch=master

.. |bitdeli| image:: https://d2weczhvl823v0.cloudfront.net/celery/vine/trend.png
    :alt: Bitdeli badge
    :target: https://bitdeli.com/free
