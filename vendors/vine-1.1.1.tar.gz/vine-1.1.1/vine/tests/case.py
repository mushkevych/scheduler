from __future__ import absolute_import, unicode_literals

import case
import sys

sys.modules[__name__] = case
