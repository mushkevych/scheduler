=====================================================================
 vine - Python Promises
=====================================================================

|build-status| |coverage| |bitdeli|

:Version: 1.1.0
:Web: http://vine.readthedocs.org/
:Download: http://pypi.python.org/pypi/vine/
:Source: http://github.com/celery/vine/
:Keywords: promise, async, future

About
=====


.. |build-status| image:: https://secure.travis-ci.org/celery/vine.png?branch=master
    :alt: Build status
    :target: https://travis-ci.org/celery/vine

.. |coverage| image:: https://codecov.io/github/celery/vine/coverage.svg?branch=master
    :target: https://codecov.io/github/celery/vine?branch=master

.. |bitdeli| image:: https://d2weczhvl823v0.cloudfront.net/celery/vine/trend.png
    :alt: Bitdeli badge
    :target: https://bitdeli.com/free

