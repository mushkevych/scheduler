# flake8: noqa
from fabric.testing.fixtures import client, remote, sftp, sftp_objs, transfer
