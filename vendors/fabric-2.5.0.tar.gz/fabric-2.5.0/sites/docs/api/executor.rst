============
``executor``
============

.. automodule:: fabric.executor
