"""Test deprecated modules from Python 3.6."""
# pylint: disable=unused-import,import-error

import optparse # [deprecated-module]
