"""test import from a builtin module"""
from __future__ import absolute_import
__revision__ = None

from math import log10

def log10_2():
    """bla bla bla"""
    return log10(2)
