"""test min methods"""
from __future__ import print_function
__revision__ = None

class Aaaa(object):
    """yo"""
    def __init__(self):
        pass
    def meth1(self):
        """hehehe"""
        print(self)
    def _dontcount(self):
        """not public"""
        print(self)
