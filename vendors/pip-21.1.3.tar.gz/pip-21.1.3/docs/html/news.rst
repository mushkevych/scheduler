=========
Changelog
=========

.. attention::

    Major and minor releases of pip also include changes listed within
    prior beta releases.

.. towncrier-draft-entries:: |release|, unreleased as on

.. pip-news-include:: ../../NEWS.rst
