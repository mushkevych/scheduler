=====================================================================
 Python AMQP 0.9.1 client library
=====================================================================

|build-status| |coverage|

.. include:: ../includes/introduction.txt

.. |build-status| image:: https://secure.travis-ci.org/celery/py-amqp.png?branch=master
    :alt: Build status
    :target: https://travis-ci.org/celery/py-amqp

.. |coverage| image:: https://codecov.io/github/celery/py-amqp/coverage.svg?branch=master
    :target: https://codecov.io/github/celery/py-amqp?branch=master
