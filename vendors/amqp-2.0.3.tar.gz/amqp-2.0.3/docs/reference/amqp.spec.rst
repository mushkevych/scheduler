=====================================================
 amqp.spec
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.spec

.. automodule:: amqp.spec
    :members:
    :undoc-members:
