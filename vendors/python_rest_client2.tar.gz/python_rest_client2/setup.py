#!/usr/bin/env python
from distutils.core import setup

long_description = """A REST Client for use in python, using httplib2 and urllib2. 

Includes a version that is suitable for use in the Google App Engine environment.
"""

setup(name             = "python-rest-client",
      version	         = "0.3",
      description      = "A REST Client for Python",
      long_description = long_description,
      author           = "Benjamin O'Steen",
      author_email     = "python-rest-client2@googlegroups.com",
      url              = "http://code.google.com/p/python-rest-client2/",
      license	         = "GPL v3",
      packages         = ['rest_client'],
     )
#      author_email     = "bosteen@gmail.com",
