==============
``exceptions``
==============

.. automodule:: fabric.exceptions
