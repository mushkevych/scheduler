## Font Awesome

## license
Font Awesome is fully open source and is GPL friendly
http://fontawesome.io/license/

# files
    css/font-awesome.css
    fonts/FontAwesome.otf
    fonts/fontawesome-webfont.eot
    fonts/fontawesome-webfont.svg
    fonts/fontawesome-webfont.ttf
    fonts/fontawesome-webfont.woff
    fonts/fontawesome-webfont.woff2

## included version
4.6.3
