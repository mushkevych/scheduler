# pylint: disable=missing-docstring

def func(first, *, second): # [unused-argument, unused-argument]
    pass
