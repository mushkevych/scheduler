# pylint: disable=import-error, unused-import, missing-docstring
CONS = 42

if __name__ == '__main__':
    CONSTANT = True
    VAR = 0
    for i in range(10):
        VAR += i

    import six
    import datetime
    import astroid
