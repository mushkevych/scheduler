ARGUMENT_FLOW_NAME = 'flow_name'
ARGUMENT_STEP_NAME = 'step_name'
ARGUMENT_RUN_MODE = 'run_mode'
RUN_MODE_RECOVERY = 'run_mode_recovery'
RUN_MODE_RUN_ONE = 'run_mode_run_one'
RUN_MODE_RUN_FROM = 'run_mode_run_from'
RUN_MODE_NOMINAL = 'run_mode_nominal'

STEP_NAME_START = 'start'
STEP_NAME_FINISH = 'finish'

COLLECTION_STEP = 'step'
COLLECTION_FLOW = 'flow'
