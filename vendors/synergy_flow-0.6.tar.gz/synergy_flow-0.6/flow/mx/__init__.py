__author__ = 'Bohdan Mushkevych'

from os import path

STATIC_FLOW_PATH = path.join(path.dirname(__file__), 'templates')
STATIC_FLOW_ENDPOINT = 'flow/static'
