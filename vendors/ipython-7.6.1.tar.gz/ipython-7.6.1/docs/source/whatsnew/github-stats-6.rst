Issues closed in the 6.x development cycle
==========================================

Issues closed in 6.3
--------------------


GitHub stats for 2017/09/15 - 2018/04/02 (tag: 6.2.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 10 issues and merged 50 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A6.3>`__

The following 35 authors contributed 253 commits.

* Anatoly Techtonik
* Antony Lee
* Benjamin Ragan-Kelley
* Corey McCandless
* Craig Citro
* Cristian Ciupitu
* David Cottrell
* David Straub
* Doug Latornell
* Fabio Niephaus
* Gergely Nagy
* Henry Fredrick Schreiner
* Hugo
* Ismael Venegas Castelló
* Ivan Gonzalez
* J Forde
* Jeremy Sikes
* Joris Van den Bossche
* Lesley Cordero
* luzpaz
* madhu94
* Matthew R. Scott
* Matthias Bussonnier
* Matthias Geier
* Olesya Baranova
* Peter Williams
* Rastislav Barlik
* Roshan Rao
* rs2
* Samuel Lelièvre
* Shailyn javier Ortiz jimenez
* Sjoerd de Vries
* Teddy Rendahl
* Thomas A Caswell
* Thomas Kluyver

Issues closed in 6.2
--------------------

GitHub stats for 2017/05/31 - 2017/09/15 (tag: 6.1.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 3 issues and merged 37 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A6.2+>`__

The following 32 authors contributed 196 commits.

* adityausathe
* Antony Lee
* Benjamin Ragan-Kelley
* Carl Smith
* Eren Halici
* Erich Spaker
* Grant Nestor
* Jean Cruypenynck
* Jeroen Demeyer
* jfbu
* jlstevens
* jus1tin
* Kyle Kelley
* M Pacer
* Marc Richter
* Marius van Niekerk
* Matthias Bussonnier
* mpacer
* Mradul Dubey
* ormung
* pepie34
* Ritesh Kadmawala
* ryan thielke
* Segev Finer
* Srinath
* Srinivas Reddy Thatiparthy
* Steven Maude
* Sudarshan Raghunathan
* Sudarshan Rangarajan
* Thomas A Caswell
* Thomas Ballinger
* Thomas Kluyver


Issues closed in 6.1
--------------------

GitHub stats for 2017/04/19 - 2017/05/30 (tag: 6.0.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 10 issues and merged 43 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A6.1+>`__

The following 26 authors contributed 116 commits.

* Alex Alekseyev
* Benjamin Ragan-Kelley
* Brian E. Granger
* Christopher C. Aycock
* Dave Willmer
* David Bradway
* ICanWaitAndFishAllDay
* Ignat Shining
* Jarrod Janssen
* Joshua Storck
* Luke Pfister
* Matthias Bussonnier
* Matti Remes
* meeseeksdev[bot]
* memeplex
* Ming Zhang
* Nick Weseman
* Paul Ivanov
* Piotr Zielinski
* ryan thielke
* sagnak
* Sang Min Park
* Srinivas Reddy Thatiparthy
* Steve Bartz
* Thomas Kluyver
* Tory Haavik


Issues closed in 6.0
--------------------

GitHub stats for 2017/04/10 - 2017/04/19 (milestone: 6.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 49 issues and merged 145 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A6.0+>`__

The following 34 authors contributed 176 commits.

* Adam Eury
* anantkaushik89
* Antonino Ingargiola
* Benjamin Ragan-Kelley
* Carol Willing
* Chilaka Ramakrishna
* chillaranand
* Denis S. Tereshchenko
* Diego Garcia
* fatData
* Fermi paradox
* fuho
* Grant Nestor
* Ian Rose
* Jeroen Demeyer
* kaushikanant
* Keshav Ramaswamy
* Matteo
* Matthias Bussonnier
* mbyt
* Michael Käufl
* michaelpacer
* Moez Bouhlel
* Pablo Galindo
* Paul Ivanov
* Piotr Przetacznik
* Rounak Banik
* sachet-mittal
* Srinivas Reddy Thatiparthy
* Tamir Bahar
* Thomas Hisch
* Thomas Kluyver
* Utkarsh Upadhyay
* Yuri Numerov
