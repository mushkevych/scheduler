Issues closed in the 7.x development cycle
==========================================

Issues closed in 7.6
--------------------

GitHub stats for 2019/04/24 - 2019/06/28 (tag: 7.5.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 9 issues and merged 43 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.6>`__

The following 19 authors contributed 144 commits.

* Alok Singh
* Andreas
* Antony Lee
* Daniel Hahler
* Ed OBrien
* Kevin Sheppard
* Luciana da Costa Marques
* Maor Kleinberger
* Matthias Bussonnier
* Miro Hrončok
* Niclas
* Nikita Bezdolniy
* Oriol Abril
* Piers Titus van der Torren
* Pragnya Srinivasan
* Robin Gustafsson
* stonebig
* Thomas A Caswell
* zzzz-qq


Issues closed in 7.5
--------------------

GitHub stats for 2019/03/21 - 2019/04/24 (tag: 7.4.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 2 issues and merged 9 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.5>`__

The following 7 authors contributed 28 commits.

* Akshay Paropkari
* Benjamin Ragan-Kelley
* Ivan Tham
* Matthias Bussonnier
* Nick Tallant
* Sebastian Witowski
* stef-ubuntu


Issues closed in 7.4
--------------------

GitHub stats for 2019/02/18 - 2019/03/21 (tag: 7.3.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 9 issues and merged 20 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.3>`__

The following 23 authors contributed 69 commits.

* anatoly techtonik
* Benjamin Ragan-Kelley
* bnables
* Frédéric Chapoton
* Gabriel Potter
* Ian Bell
* Jake VanderPlas
* Jan S. (Milania1)
* Jesse Widner
* jsnydes
* Kyungdahm Yun
* Laurent Gautier
* Luciana da Costa Marques
* Matan Gover
* Matthias Bussonnier
* memeplex
* Mickaël Schoentgen
* Partha P. Mukherjee
* Philipp A
* Sanyam Agarwal
* Steve Nicholson
* Tony Fast
* Wouter Overmeire


Issues closed in 7.3
--------------------

GitHub stats for 2018/11/30 - 2019/02/18 (tag: 7.2.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 4 issues and merged 20 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.3>`__

The following 17 authors contributed 99 commits.

* anatoly techtonik
* Benjamin Ragan-Kelley
* Gabriel Potter
* Ian Bell
* Jake VanderPlas
* Jan S. (Milania1)
* Jesse Widner
* Kyungdahm Yun
* Laurent Gautier
* Matthias Bussonnier
* memeplex
* Mickaël Schoentgen
* Partha P. Mukherjee
* Philipp A
* Sanyam Agarwal
* Steve Nicholson
* Tony Fast

Issues closed in 7.2
--------------------

GitHub stats for 2018/10/28 - 2018/11/29 (tag: 7.1.1)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 2 issues and merged 18 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.2>`__

The following 16 authors contributed 95 commits.

* Antony Lee
* Benjamin Ragan-Kelley
* CarsonGSmith
* Chris Mentzel
* Christopher Brown
* Dan Allan
* Elliott Morgan Jobson
* is-this-valid
* kd2718
* Kevin Hess
* Martin Bergtholdt
* Matthias Bussonnier
* Nicholas Bollweg
* Pavel Karateev
* Philipp A
* Reuben Morais

Issues closed in 7.1
--------------------

GitHub stats for 2018/09/27 - 2018/10/27 (since tag: 7.0.1)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 31 issues and merged 54 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.1>`__

The following 33 authors contributed 254 commits.

* ammarmallik
* Audrey Dutcher
* Bart Skowron
* Benjamin Ragan-Kelley
* BinaryCrochet
* Chris Barker
* Christopher Moura
* Dedipyaman Das
* Dominic Kuang
* Elyashiv
* Emil Hessman
* felixzhuologist
* hongshaoyang
* Hugo
* kd2718
* kory donati
* Kory Donati
* koryd
* luciana
* luz.paz
* Massimo Santini
* Matthias Bussonnier
* Matthias Geier
* meeseeksdev[bot]
* Michael Penkov
* Mukesh Bhandarkar
* Nguyen Duy Hai
* Roy Wellington Ⅳ
* Sha Liu
* Shao Yang
* Shashank Kumar
* Tony Fast
* wim glenn


Issues closed in 7.0
--------------------

GitHub stats for 2018/07/29 - 2018/09/27 (since tag: 6.5.0)

These lists are automatically generated, and may be incomplete or contain duplicates.

We closed 20 issues and merged 76 pull requests.
The full list can be seen `on GitHub <https://github.com/ipython/ipython/issues?q=milestone%3A7.0>`__

The following 49 authors contributed 471 commits.

* alphaCTzo7G
* Alyssa Whitwell
* Anatol Ulrich
* apunisal
* Benjamin Ragan-Kelley
* Chaz Reid
* Christoph
* Dale Jung
* Dave Hirschfeld
* dhirschf
* Doug Latornell
* Fernando Perez
* Fred Mitchell
* Gabriel Potter
* gpotter2
* Grant Nestor
* hongshaoyang
* Hugo
* J Forde
* Jonathan Slenders
* Jörg Dietrich
* Kyle Kelley
* luz.paz
* M Pacer
* Matthew R. Scott
* Matthew Seal
* Matthias Bussonnier
* meeseeksdev[bot]
* Michael Käufl
* Olesya Baranova
* oscar6echo
* Paul Ganssle
* Paul Ivanov
* Peter Parente
* prasanth
* Shailyn javier Ortiz jimenez
* Sourav Singh
* Srinivas Reddy Thatiparthy
* Steven Silvester
* stonebig
* Subhendu Ranjan Mishra
* Takafumi Arakaki
* Thomas A Caswell
* Thomas Kluyver
* Todd
* Wei Yen
* Yarko Tymciurak
* Yutao Yuan
* Zi Chong Kao
