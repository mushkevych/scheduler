===============
IPython options
===============

Any of the options listed here can be set in config files, at the
command line, or from inside IPython. See :ref:`setting_config` for
details.

.. toctree::

   terminal
   kernel
