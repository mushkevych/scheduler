# This __init__.py has a module-level docstring, which is counted as a
# statement.
"""A simple package for testing with."""
print("pkg1.__init__: %s" % (__name__,))
