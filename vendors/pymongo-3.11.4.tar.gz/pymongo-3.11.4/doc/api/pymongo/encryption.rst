:mod:`encryption` -- Client-Side Field Level Encryption
=======================================================

.. automodule:: pymongo.encryption
   :members:
