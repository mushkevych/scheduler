:mod:`event_loggers` -- Example loggers
===========================================


.. automodule:: pymongo.event_loggers
   :synopsis: A collection of simple listeners for monitoring driver events.
   :members: