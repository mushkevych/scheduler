1.2
===

Issue #5: Added a minimal test suite.

1.1
===

Moved hosting to Github.
Library uses setuptools_scm for version tagging.
Added license declaration.
