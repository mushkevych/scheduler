Welcome to backports.functools_lru_cache documentation!
========================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: backports.functools_lru_cache
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

