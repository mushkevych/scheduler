.. _extensions_autoreload:

==========
autoreload
==========

.. magic:: autoreload

.. automodule:: IPython.extensions.autoreload
