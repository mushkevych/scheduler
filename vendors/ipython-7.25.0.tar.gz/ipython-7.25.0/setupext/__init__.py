# load extended setup modules for distutils

from .install_data_ext import install_data_ext
