# -*- coding: utf-8 -*-
"""
    plnt
    ~~~~

    Noun. plnt (plant) -- a planet application that sounds like a herb.

    :copyright: 2007 Pallets
    :license: BSD-3-Clause
"""
from .webapp import Plnt
