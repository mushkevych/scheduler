__author__ = 'Bohdan Mushkevych'

from os import path

STATIC_FLOW_PATH = path.dirname(__file__)
STATIC_FLOW_ENDPOINT = 'flow/static'
