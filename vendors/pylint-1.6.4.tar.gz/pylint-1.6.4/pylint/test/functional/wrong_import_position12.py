"""Checks import position rule"""
# pylint: disable=unused-import,relative-import,ungrouped-imports,import-error,no-name-in-module,pointless-string-statement
"Two string"

import os  # [wrong-import-position]
