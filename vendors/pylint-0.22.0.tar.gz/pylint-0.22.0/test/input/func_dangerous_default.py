"""docstring"""

__revision__ = ''

HEHE = {}

def function1(value = []):
    """docstring"""
    print value

def function2(value = HEHE):
    """docstring"""
    print value

def function3(value):
    """docstring"""
    print value
