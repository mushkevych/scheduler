============
``__init__``
============

.. automodule:: invoke
