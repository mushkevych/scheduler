from invoke import task


@task
def i_have_underscores(c):
    pass
